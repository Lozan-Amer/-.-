public class Main {
    public static void main(String[] args) {
        QRController controller = new QRController("ABC123");
        controller.showQR();
    }
}
